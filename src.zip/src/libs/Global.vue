<template>

</template>

<script>
const getTrunkImg = 'http://49.232.244.63:5005/trunk_img/'
const getRootImg = 'http://49.232.244.63:5005/root_img/'
export default {
  name: "Global",
  getTrunkImg,
  getRootImg,
}
</script>

<style scoped>

</style>
