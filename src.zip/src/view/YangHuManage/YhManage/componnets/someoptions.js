export const yhTypeList = [
  {
    value: '日常养护管理',
  },
  {
    value: '修剪',
  },
  {
    value: '树体保护措施',
  },
  {
    value: '生长环境保护与改善',
  },
  {
    value: '病虫害防治',
  },
  {
    value: '巡查工作',
  }
]
