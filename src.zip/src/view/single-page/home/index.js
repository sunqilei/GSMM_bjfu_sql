import home from './home.vue'
export default home
